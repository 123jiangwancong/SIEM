function [GGa,dG]=Graforwardmodel(t,n,x1,y1,z1,l,F,parameter)
%测网坐标///////////////////////////////////
xbegin=parameter(1);
ybegin=parameter(2);
xend=parameter(4);
yend=parameter(5);
dx=parameter(7);
dy=parameter(8);
Dx=xbegin:dx:xend;
Dy=ybegin:dy:yend;
[xp,yp]=meshgrid(Dx,Dy);
m1=size(xp,1);%列数
m2=size(xp,2);%行数
zp=zeros(m1,m2);
zp=zp+parameter(10);%下方
zp1=zp+parameter(11);%上方
ga=zeros(1,t);
ga1=zeros(1,t);
nz=[0;0;1];
a=F;
G=6.67*10^(-3);%此时重力异常的单位是毫伽
for k=1:m1
    for i=1:m2
        for j=1:t
        ga(j)=a*G*l(j)./((xp(k,i)-x1(j)).^2+(yp(k,i)-y1(j)).^2+(zp(k,i)-z1(j)).^2).^(1/2).*n(j,:)*nz;
        ga1(j)=a*G*l(j)./((xp(k,i)-x1(j)).^2+(yp(k,i)-y1(j)).^2+(zp1(k,i)-z1(j)).^2).^(1/2).*n(j,:)*nz;
        end
    GGa(k,i)=sum(ga);
    GGa1(k,i)=sum(ga1);
    end
end
dG=((GGa-GGa1)./(parameter(11)-parameter(10)))*1000;%单位为gmal/kmnull
