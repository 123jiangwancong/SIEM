function Vertices1=MarchingCubes(X,Y,Z,V,a)
%%% data type to single
X = single(X);
Y = single(Y);
Z = single(Z);
V = single(V);
isovalue = single(a);
% Marching cubes
[Vertices1, Indices1] = getSurfaceNoOpt(X, Y, Z, V,isovalue);
% % % % visualize triangles
%figure(1)
%p = patch('Faces', Indices1, 'Vertices', Vertices1);
%set(p, 'FaceColor', 'none', 'EdgeColor', 'red');
%daspect([1,1,1])
%grid on
%xlim([0 200000])
%ylim([0 200000])
%zlim([-40000 0])
%xticks([0 50000 100000 150000 200000])
%xticklabels({'0','50','100','150','200'})
%yticks([0 50000 100000 150000 200000])
%yticklabels({'0','50','100','150','200'})
%zticks([-40000 -30000 -20000 -10000 0 ])
%zticklabels({'-40','-30','-20','-10','0'})
%xlabel('X/km')
%ylabel('Y/km')
%zlabel('Z/km')
%hold on
%[~,n,xx,yy,zz]=normvector(Vertices1');n=-n';
%quiver3(xx,yy,zz,n(1,:),n(2,:),n(3,:))
%hold off
endnull
