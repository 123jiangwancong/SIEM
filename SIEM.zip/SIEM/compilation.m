function E=compilation(data,p,q,parameter)
p=p*10^(-3);
q=q*10^(-1);
data=data';
[m,N,x,y,z]=normvector(data);%求法向量和三角元面积
t=length(N);
N=-N;
%正演开始//////////////////////////////////////
[T,dT]=Magforwardmodel(t,N,x,y,z,m,p,parameter);
[G,dG]=Graforwardmodel(t,N,x,y,z,m,q,parameter);
E(:,:,1)=dT;
E(:,:,2)=T;
E(:,:,3)=dG;
E(:,:,4)=G;null
