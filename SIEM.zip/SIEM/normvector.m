function [S,n,x1,y1,z1]=normvector(data)
  [~,cols]=size(data);
  %计算可以完整组成的三角形数量（每3列一个三角形）
  %使用floor确保只处理完整的三角形，丢弃多余的列
  numTriangles=floor(cols/3);
  S=zeros(1,numTriangles);
  n=zeros(numTriangles,3);
  x1=zeros(1,numTriangles);
  y1=zeros(1,numTriangles);
  z1=zeros(1,numTriangles);
for i=1:numTriangles
    s=data(1:3,(i-1)*3+1:i*3);%提取单个面元的三点坐标（3行X3列）
    a=s(:,2)-s(:,1);
    b=s(:,3)-s(:,1);  
    c=cross(a,b);  
   %计算每个面元上的外法向向量
    %防止除以0（三点连线，norm为0）
    norm_c=norm(c,2);
    if norm_c<eps
        n(i,:)=[0 0 1];
    else
        n(i,:)=c./norm(c,2);%单位化
    end
    X=(s(2,2)-s(2,1))*(s(3,3)-s(3,1))-(s(2,3)-s(2,1))*(s(3,2)-s(3,1));
    Y=(s(1,3)-s(1,1))*(s(3,2)-s(3,1))-(s(1,2)-s(1,1))*(s(3,3)-s(3,1));
    Z=(s(1,2)-s(1,1))*(s(2,3)-s(2,1))-(s(1,3)-s(1,1))*(s(2,2)-s(2,1));
    S(i)=sqrt(X^2+Y^2+Z^2)*0.5;%每个三角面元的面积
    x1(i)=sum(s(1,:))/3;
    y1(i)=sum(s(2,:))/3;
    z1(i)=sum(s(3,:))/3;%每个面元的中心点坐标
end
endnull
