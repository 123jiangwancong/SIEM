function [T0,dT]=Magforwardmodel(t,n,x1,y1,z1,h,J,parameter)%This script is for DL
%测网坐标///////////////////////////////////
xbegin=parameter(1);
ybegin=parameter(2);
xend=parameter(4);
yend=parameter(5);
dx=parameter(7);
dy=parameter(8);
Dx=xbegin:dx:xend;
Dy=ybegin:dy:yend;
[xp,yp]=meshgrid(Dx,Dy);
m1=size(xp,1);%行数
m2=size(xp,2);%列数
zp=zeros(m1,m2);
zp=zp+parameter(10);
zp1=zp+parameter(11);
%%磁性参数//////////////////////////////////
B=parameter(12);%磁化场总强度
D=parameter(13)/180;%磁偏角，与北向（也即X轴的夹角）
I=parameter(14)/180;%磁倾角，从地面向下算起，和地面之间的夹角
k2=J;%异常体磁化率
k1=0;%土壤磁化率设为0
u0=4*pi*10^-7;
u1=(1+k1)*u0;
u2=(1+k2)*u0;
K=(u2-u1)/(u2+u1);
Nx=cospi(I)*cospi(D);
Ny=cospi(I)*sinpi(D);
Nz=sinpi(I);%地磁场的方向矢量
%磁场量/////////////////////////////
hax=zeros(1,t);
hay=zeros(1,t);
hax1=zeros(1,t);
hay1=zeros(1,t);
za=zeros(1,t);
za1=zeros(1,t);
Hax=zeros(m2,m1);
Hax1=zeros(m2,m1);
Hay=zeros(m2,m1);
Hay1=zeros(m2,m1);
Za=zeros(m2,m1);
Za1=zeros(m2,m1);
r=zeros(t,t);
A=zeros(t,t);
for i=1:t
    for j=1:t
        r(i,j)=sqrt((x1(i)-x1(j))^2+(y1(i)-y1(j))^2+(z1(i)-z1(j))^2+eps);
        if i==j
            A(i,j)=1;
        else
            A(i,j)=K/(2*pi)*h(j)*((x1(j)-x1(i)).*n(j,1)+(y1(j)-y1(i)).*...
                n(j,2)+(z1(j)-z1(i)).*n(j,3))./r(i,j)^3+K;
        end
    end
end
f=zeros(t,1);
for i=1:t
    f(i)=B*[Nx,Ny,Nz]*n(i,:)';
end
sigma=pinv(A)*f;
if any(isnan(sigma))||any(isinf(sigma))
    warning('Sigma出现NaN或Inf,可能由于矩阵A病态或数据异常。')
end
for i=1:m1%number of rows
  for k=1:m2%number of columns
    for j=1:t
        hax(j)=-K/(2*pi)*sigma(j)*h(j).*(-xp(i,k)+x1(j))./...
            (sqrt((xp(i,k)-x1(j))^2+(yp(i,k)-y1(j))^2+(zp(i,k)-z1(j))^2)+eps)^3;
        hay(j)=-K/(2*pi)*sigma(j)*h(j).*(-yp(i,k)+y1(j))./...
             (sqrt((xp(i,k)-x1(j))^2+(yp(i,k)-y1(j))^2+(zp(i,k)-z1(j))^2)+eps)^3;
        za(j)=-K/(2*pi)*sigma(j)*h(j).*(-zp(i,k)+z1(j))./...
             (sqrt((xp(i,k)-x1(j))^2+(yp(i,k)-y1(j))^2+(zp(i,k)-z1(j))^2)+eps)^3;
         hax1(j)=-K/(2*pi)*sigma(j)*h(j).*(-xp(i,k)+x1(j))./...
               (sqrt((xp(i,k)-x1(j))^2+(yp(i,k)-y1(j))^2+(zp1(i,k)-z1(j))^2)+eps)^3;
         hay1(j)=-K/(2*pi)*sigma(j)*h(j).*(-yp(i,k)+y1(j))./...
               (sqrt((xp(i,k)-x1(j))^2+(yp(i,k)-y1(j))^2+(zp1(i,k)-z1(j))^2)+eps)^3;
         za1(j)=-K/(2*pi)*sigma(j)*h(j).*(-zp1(i,k)+z1(j))./...
               (sqrt((xp(i,k)-x1(j))^2+(yp(i,k)-y1(j))^2+(zp1(i,k)-z1(j))^2)+eps)^3;
    end
    Hax(i,k)=sum(hax);
    Hay(i,k)=sum(hay);
    Za(i,k)=sum(za);
    Hax1(i,k)=sum(hax1);
    Hay1(i,k)=sum(hay1);
    Za1(i,k)=sum(za1);
  end
end
T0=Za.*Nz+Hax.*Nx+Hay.*Ny;
T1=Za1.*Nz+Hax1.*Nx+Hay1.*Ny;
dT=((T0-T1)./(parameter(11)-parameter(10)))*1000;%单位为nT/kmnull
