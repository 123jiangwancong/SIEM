function [E,label]=randomrize(parameter)
seed=parameter(17);
%%火成岩侵入沉积岩随着基性程度加深，磁化率增加，且密度增加，依次为中酸性岩 基性岩 超基性岩
sus=[ 0.1 1 2 3 4 5 6 7 8 9 10];   %相对磁化率
dens=[ -5 -4 -3 -2 -1 0.1 1 2 3 4 5];     %相对密度
xbegin=parameter(1);
ybegin=parameter(2);
zbegin=parameter(3);
xend=parameter(4);
yend=parameter(5);
zend=parameter(6);
dx=parameter(7);
dy=parameter(8);
dz=parameter(9);
Dx=xbegin:dx:xend;
Dy=ybegin:dy:yend;
Dz =zbegin:dz:zend;%负向量
[X,Y,Z] = ndgrid(Dx,Dy,Dz);
lx=length(Dx);
ly=length(Dy);
lz=length(Dz);
rx=ceil(lx/2);%模型起点在X方向的取值范围
ry=ceil(ly/2);%模型起点在Y方向的取值范围
rz=ceil(lz/2);%模型起点Z方向长度取值范围，模型至少有一个点在窗口内
longth=floor(lx/2);%模型的长的范围
width=floor(ly/2);%模型的宽的范围
depth=floor(lz/2);%模型厚度的范围
Vol=zeros(lx,ly,lz,'double');
datacell=cell(1,seed);
E=zeros(lx,ly,4,seed,'double');
temp1=zeros(lx,ly,lz,seed,'double');
temp2=zeros(lx,ly,lz,seed,'double');
x=randperm(rx,min(seed,rx));
y=randperm(ry,min(seed,ry)); 
z=randperm(rz,min(seed,rz));
ax=randi([2,longth],1,seed);
ay=randi([2,width],1,seed);
az=randi([2,depth],1,seed);
for i=1:seed
    x_start=max(2,x(i));
    x_end=min(lx-1,x_start+ax(i));
    y_start=max(2,y(i));
    y_end=min(ly-1,y_start+ay(i));
    z_start=max(2,z(i));
    z_end=min(lz-1,z_start+az(i));
    Vol(x_start:x_end,y_start:y_end,z_start:z_end)=i;%重合的地方被后着覆盖
end
for i=1:seed
    V0_vol=(Vol==i);
    V0_vol=logical(V0_vol);
    V0_vol(isnan(V0_vol))=0;%强制洗零
    datacell{i}=MarchingCubes(X,Y,Z,V0_vol,1);
    v_s=sus(randi(length(sus))); 
    v_d=dens(randi(length(dens))); 
    E(:,:,:,i)=compilation(datacell{i},v_s,v_d,parameter);%计算四个值，从上到下是先重后磁
    temp1(:,:,:,i)=v_s.*V0_vol;
    temp2(:,:,:,i)=v_d.*V0_vol;
    clear V0_vol
end
%%%
%输出网格数据
E=sum(E,4);
temp1=sum(temp1,4);
temp2=sum(temp2,4);
label=cat(3,temp1,temp2);%制作标签
endnull
