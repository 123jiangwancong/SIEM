clear,clc
%/////////////////////////////////正演参数
parameter(1) =0;       %第一个参数是模型空间按X方向剖分起点坐标
parameter(2) =0;       %第二个参数是模型空间按Y方向剖分起点坐标
parameter(3) =0;       %第三个参数是模型空间按Z方向剖分起点坐标
parameter(4) =200000;    %第四个参数是模型空间按X方向剖分终点坐标
parameter(5) =200000;    %第五个参数是模型空间按Y方向剖分终点坐标
parameter(6)=-30000;     %第六个参数是模型空间按Z方向剖分终点坐标
parameter(7)=5000;       %第七个参数是模型空间的剖分间距（X方向）
parameter(8)=5000;        %第八个参数是模型空间的剖分间距（Y方向）
parameter(9)=-2000;       %第九个参数是模型空间的剖分间距（Z方向）
parameter(10)=1;       %第十个参数是下方探头的高度
parameter(11)=1.5;     %第十一个参数是上方探头的高度
parameter(12)=50000;   %第十二个参数是地磁场场强；
parameter(13)=0.1;       %第十三个参数是磁偏角/度
parameter(14)=89.9;      %第十四个参数是磁倾角/度
parameter(15)=10;       %第十五个参数是磁化率最大值
parameter(16)=5;       %第十六个参数是剩余密度最大值
parameter(17)=1;       %第十七个参数是模型个数
parameter(18)=0;         %第十八个参数是剩余磁化强度磁倾角
parameter(19)=0;        %第十九个参数是剩余磁化强度磁偏角
parameter(20)=0;        %第二十个参数是剩余磁化强度强度         
%////////////////////////////////////////////////////
n=10000; 
for i=1:2:n
      % % 以上参数表赋值完毕    
       if i>floor(n/3)&&i<ceil(n/3*2)
           parameter(17)=2;
       elseif i>floor(n/3*2)
          parameter(17)=3;
       end
      % cla(figure(1))
      [samples,labels]=randomrize(parameter);
      c=size(samples,1);
      r=size(samples,2);
      Nsamples(:,:,1)=samples(:,:,1)+rand(r,c)*max(max(samples(:,:,1)))*0.1;
      Nsamples(:,:,2)=samples(:,:,2)+rand(r,c)*max(max(samples(:,:,2)))*0.1;
      Nsamples(:,:,3)=samples(:,:,3)+rand(r,c)*max(max(samples(:,:,3)))*0.1;
      Nsamples(:,:,4)=samples(:,:,4)+rand(r,c)*max(max(samples(:,:,4)))*0.1;
      % figure(2)
      % 
      % subplot(2,2,1)
      % imagesc(samples(:,:,1))
      % xlabel('X/km')
      % ylabel('Y/km')
      % xticks([1 11 21 31 41]);
      % xticklabels({'0','50','100','150','200'});
      % yticks([1 11 21 31 41]);
      % yticklabels({'0','50','100','150','200'});
      % title('MGA')
      % p=colorbar;
      % set(get(p,'Title'),'string','nT/km');
      % set(gca,'YDir','normal'); 
      % 
      % subplot(2,2,2)
      % imagesc(samples(:,:,2))
      % xlabel('X/km')
      % ylabel('Y/km')
      % xticks([1 11 21 31 41]);
      % xticklabels({'0','50','100','150','200'});
      % yticks([1 11 21 31 41]);
      % yticklabels({'0','50','100','150','200'});
      % title('MA')
      % p=colorbar;
      % set(get(p,'Title'),'string','nT');
      % set(gca,'YDir','normal');
      % 
      % subplot(2,2,3)
      % imagesc(samples(:,:,3))
      % xlabel('X/km')
      % ylabel('Y/km')
      % xticks([1 11 21 31 41]);
      % xticklabels({'0','50','100','150','200'});
      % yticks([1 11 21 31 41]);
      % yticklabels({'0','50','100','150','200'});
      % title('GGA')
      % p=colorbar;
      % set(get(p,'Title'),'string','mGal/km');
      % set(gca,'YDir','normal');
      % 
      % subplot(2,2,4)
      % imagesc(samples(:,:,4))
      % xlabel('X/km')
      % ylabel('Y/km')
      % xticks([1 11 21 31 41]);
      % xticklabels({'0','50','100','150','200'});
      % yticks([1 11 21 31 41]);
      % yticklabels({'0','50','100','150','200'});
      % title('GA')
      % p=colorbar;
      % set(get(p,'Title'),'string','mGal');
      % set(gca,'YDir','normal');
      % 
      % figure(3)
      % subplot(2,2,1)
      % imagesc(Nsamples(:,:,1))
      % xlabel('X/km')
      % ylabel('Y/km')
      % xticks([1 11 21 31 41]);
      % xticklabels({'0','50','100','150','200'});
      % yticks([1 11 21 31 41]);
      % yticklabels({'0','50','100','150','200'});
      % title('MGA')
      % p=colorbar;
      % set(get(p,'Title'),'string','nT/km');
      % set(gca,'YDir','normal');
      % 
      % subplot(2,2,2)
      % imagesc(Nsamples(:,:,2))
      % xlabel('X/km')
      % ylabel('Y/km')
      % xticks([1 11 21 31 41]);
      % xticklabels({'0','50','100','150','200'});
      % yticks([1 11 21 31 41]);
      % yticklabels({'0','50','100','150','200'});
      % title('MA')
      % p=colorbar;
      % set(get(p,'Title'),'string','nT');
      % set(gca,'YDir','normal');
      % 
      % subplot(2,2,3)
      % imagesc(Nsamples(:,:,3))
      % xlabel('X/km')
      % ylabel('Y/km')
      % xticks([1 11 21 31 41]);
      % xticklabels({'0','50','100','150','200'});
      % yticks([1 11 21 31 41]);
      % yticklabels({'0','50','100','150','200'});
      % title('GGA')
      % p=colorbar;
      % set(get(p,'Title'),'string','mGal/km');
      % set(gca,'YDir','normal');
      % 
      % subplot(2,2,4)
      % imagesc(Nsamples(:,:,4))
      % xlabel('X/km')
      % ylabel('Y/km')
      % xticks([1 11 21 31 41]);
      % xticklabels({'0','50','100','150','200'});
      % yticks([1 11 21 31 41]);
      % yticklabels({'0','50','100','150','200'});
      % title('GA')
      % p=colorbar;
      % set(get(p,'Title'),'string','mGal');
      % set(gca,'YDir','normal');


      TrainData(:,:,:,i)=samples;
      Label(:,:,:,i)=labels;
      TrainData(:,:,:,i+1)=Nsamples;
      Label(:,:,:,i+1)=labels;
      Label=single(Label);
end


save("NewLabel_12-24.mat","Label",'-v7.3');
save("NewData_12-24.mat","TrainData");